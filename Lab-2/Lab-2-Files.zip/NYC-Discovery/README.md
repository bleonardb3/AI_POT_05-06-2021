# Discovery Output Files for NYC Posts
This folder contains the Discovery output files for the NYC posts.
