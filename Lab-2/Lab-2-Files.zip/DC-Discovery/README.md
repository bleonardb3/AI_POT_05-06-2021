# Discovery Output Files for DC Posts
This folder contains the Discovery output files for the DC posts.
